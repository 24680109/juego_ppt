import flet as ft
import random

def main(page: ft.Page):
    # --- CONFIGURACIÓN DE LA VENTANA ---
    page.title = "Piedra, Papel o Tijera"
    # Centramos el contenido horizontal y verticalmente
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    # Personalización de colores: Fondo cremita y modo claro
    page.bgcolor = "#E0DCF5"  # Color crema (Beige/Cream)
    page.theme_mode = ft.ThemeMode.LIGHT
    
    # Dimensiones de la ventana
    page.window_width = 450
    page.window_height = 550

    # --- LÓGICA DEL JUEGO ---
    opciones = ["PIEDRA", "PAPEL", "TIJERAS"]
    # Definimos el color vino para usarlo en los textos
    color_vino = "#7E8000"

    def determinar_ganador(usuario, computadora):
        """Compara la elección del usuario contra la computadora"""
        if usuario == computadora:
            return "¡Es un empate! "
        
        # Reglas: Piedra vence a tijeras, Papel a piedra, Tijeras a papel
        ganas = (
            (usuario == "PIEDRA" and computadora == "TIJERAS") or
            (usuario == "PAPEL" and computadora == "PIEDRA") or
            (usuario == "TIJERAS" and computadora == "PAPEL")
        )
        
        return "¡Ganaste! Felicidades :)" if ganas else "Perdiste... suerte la próxima :("

    def jugar(e):
        """Función que se ejecuta al presionar un botón"""
        # La computadora elige una opción al azar de la lista
        eleccion_computadora = random.choice(opciones)
        # Obtenemos la elección del usuario desde el atributo 'data' del botón
        eleccion_usuario = e.control.data
        
        # Obtenemos el texto del resultado
        resultado = determinar_ganador(eleccion_usuario, eleccion_computadora)
        
        # Actualizamos los textos en la pantalla
        txt_vs.value = f"Tú: {eleccion_usuario}  vs  Dispositivo: {eleccion_computadora}"
        txt_resultado.value = resultado
        page.update()

    # --- ELEMENTOS VISUALES (INTERFAZ) ---
    # Título principal con color vino
    txt_titulo = ft.Text(
        "¡Elige una opción!", 
        size=30, 
        weight=ft.FontWeight.BOLD, 
        color=color_vino
    )
    
    # Texto que mostrará el enfrentamiento (Tú vs Computadora)
    txt_vs = ft.Text("", size=18, italic=True, color=color_vino)
    
    # Texto que mostrará si ganaste o perdiste
    txt_resultado = ft.Text("", size=22, weight=ft.FontWeight.W_600, color=color_vino)

    # Fila de botones con emojis
    botones = ft.Row(
        controls=[
            # Cada botón tiene 'data' para saber qué eligió el usuario
            ft.ElevatedButton(" Piedra", on_click=jugar, data="PIEDRA", width=120, height=60),
            ft.ElevatedButton(" Papel", on_click=jugar, data="PAPEL", width=120, height=60),
            ft.ElevatedButton(" Tijeras", on_click=jugar, data="TIJERAS", width=120, height=60),
        ],
        alignment=ft.MainAxisAlignment.CENTER
    )

    # --- MONTAJE DE LA PÁGINA ---
    # Usamos una columna para organizar todo de arriba hacia abajo
    page.add(
        ft.Column(
            controls=[
                txt_titulo,
                ft.Divider(height=20, color="transparent"), # Espacio invisible
                botones,
                ft.Divider(height=40, color=color_vino),    # Línea divisoria color vino
                txt_vs,
                txt_resultado,
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

# Punto de entrada de la aplicación
if __name__ == "__main__":
    ft.app(target=main, view=ft.AppView.WEB_BROWSER)